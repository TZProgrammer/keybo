**English Version:**

1. **typingdata1278.json**  
   - Data collected using vocabulary selected from Monkeytype's dictionary database  
   - Words were chosen to alternate between home row letters (Colemak-DH layout) and other letters  
   - Words were selected from all available language dictionaries  
   - Special characters (/, .) were added at word endings to cover the entire keyboard  
   - Increased frequency of rarely used characters (like x and q)  

2. **typingdata0003.json**  
   - Data collected from typing pseudo-words composed of random letters  
   - Uses a set of 30 available keyboard characters  
   - Designed to force finger return to home row  
   - Words alternate with middle row letters (home row in Colemak-DH)  

**Polish Version:**

1. **typingdata1278.json**  
   - Dane zebrane na podstawie słownictwa wybranego z bazy słowników Monkeytype  
   - Słowa dobrane tak, aby na przemian występowały litery z home row (układ Colemak-DH) i inne litery  
   - Słowa wybrane ze wszystkich dostępnych słowników językowych  
   - Na końcach słów dodano znaki specjalne (/, .) aby objąć całą klawiaturę  
   - Zwiększona częstotliwość rzadko używanych znaków (jak x i q)  

2. **typingdata0003.json**  
   - Dane zebrane podczas pisania pseudowyrazów z losowych liter  
   - Zestaw 30 dostępnych znaków klawiatury  
   - Zaprojektowane tak, aby wymuszać powrót palców do home row  
   - Litery przeplatane ze środkowego rzędu (home row w Colemak-DH)  
